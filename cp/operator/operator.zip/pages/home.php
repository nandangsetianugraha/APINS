<?php 
include "../inc/lte-head.php";
?>
<body class="hold-transition skin-blue sidebar-mini">
<!-- Content Header (Page header) -->


<!-- Main content -->
<section class="content">
<?php
$tgl=isset($_GET['tanggal']) ? $_GET['tanggal'] : date("d");
$bln=isset($_GET['bulan']) ? $_GET['bulan'] : date("m");
$thn=isset($_GET['tahun']) ? $_GET['tahun'] : date("Y");
$BulanIndo = array("Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember");
$sq2=mysqli_query($koneksi, "select * from penempatan JOIN siswa USING(peserta_didik_id) where siswa.jk='L' and penempatan.tapel='$tpl_aktif'");
				$sq3=mysqli_query($koneksi, "select * from penempatan JOIN siswa USING(peserta_didik_id) where siswa.jk='P' and penempatan.tapel='$tpl_aktif'");
				$juml=mysqli_num_rows($sq2);
				$jump=mysqli_num_rows($sq3);
				
				$total=$juml+$jump;
				if($total>0){
					$perlak=($juml/$total)*100;
					$perper=($jump/$total)*100;
				}else{
					$perlak=0;
					$perper=0;
				};
				
				$sabsen=mysqli_query($koneksi, "select * from penempatan where tapel='$tpl_aktif'");
				$sakit=0;
				$ijin=0;
				$alfa=0;
				while($mk=mysqli_fetch_array($sabsen)){
					$pds=$mk['peserta_didik_id'];
					$snama=mysqli_query($koneksi, "select *,SUM(IF(absensi='S',1,0)) AS sakit,SUM(IF(absensi='I',1,0)) AS ijin,SUM(IF(absensi='A',1,0)) AS alfa from absensi where tanggal LIKE '$thn-$bln-%' and peserta_didik_id='$pds'");
					$jab=mysqli_fetch_array($snama);
					$sakit=$sakit+$jab['sakit'];
					$ijin=$ijin+$jab['ijin'];
					$alfa=$alfa+$jab['alfa'];
				};
				$jkeh=$sakit+$ijin+$alfa;
				$hef=mysqli_query($koneksi,"select * from hari_efektif where bulan='$bln' and tapel='$tpl_aktif'");
				$efek=mysqli_fetch_array($hef);
				if($efek['hari']==0){
					$harim=23;
				}else{
					$harim=$efek['hari'];
				};
				$hefek=round(($jkeh*100)/($harim*$total),2);
				
				
?>
		<div class="row">
			
			<div class="col-lg-3 col-xs-6">
				<div class="small-box bg-aqua">
					<div class="inner">
					  <h3><?=$total;?></h3>

					  <p>Siswa Kelas</p>
					</div>
					<div class="icon">
					  <i class="fa fa-users"></i>
					</div>
					<a href="#" class="small-box-footer">
					  More info <i class="fa fa-arrow-circle-right"></i>
					</a>
				 </div>
			</div>
			<div class="col-lg-3 col-xs-6">
				<div class="small-box bg-green">
					<div class="inner">
					  <h3><?=$jump;?></h3>

					  <p>Jumlah Perempuan</p>
					</div>
					<div class="icon">
					  <i class="fa fa-female"></i>
					</div>
					<a href="#" class="small-box-footer">
					  More info <i class="fa fa-arrow-circle-right"></i>
					</a>
				 </div>
			</div>
			<div class="col-lg-3 col-xs-6">
				<div class="small-box bg-yellow">
					<div class="inner">
					  <h3><?=$juml;?></h3>

					  <p>Jumlah Laki-laki</p>
					</div>
					<div class="icon">
					  <i class="fa fa-male"></i>
					</div>
					<a href="#" class="small-box-footer">
					  More info <i class="fa fa-arrow-circle-right"></i>
					</a>
				 </div>
			</div>
		</div>

      <!-- Default box -->
	  <div class="row">
		<div class="col-lg-6 col-xs-12">
			<div class="box">
				<div class="box-header with-border">
				  <h3 class="box-title">Data Absensi Bulan <?=$BulanIndo[(int)$bln-1];?></h3>
				</div>
				<div class="box-body">
					<div class="row">
						<div class="col-lg-12 col-xs-6">
							<div class="small-box bg-red">
								<div class="inner">
								  <h3><?=$hefek;?>%</h3>

								  <p>Persentase Absen</p>
								</div>
								<div class="icon">
								  <i class="fa fa-bar-chart"></i>
								</div>
								
							 </div>
						</div>
						<div class="col-lg-4 col-xs-6">
							<div class="small-box bg-aqua">
								<div class="inner">
								  <h3><?=$sakit;?></h3>

								  <p>Sakit</p>
								</div>
								<div class="icon">
								  <i class="fa fa-users"></i>
								</div>
							 </div>
						</div>
						<div class="col-lg-4 col-xs-6">
							<div class="small-box bg-aqua">
								<div class="inner">
								  <h3><?=$ijin;?></h3>

								  <p>Ijin</p>
								</div>
								<div class="icon">
								  <i class="fa fa-users"></i>
								</div>
							 </div>
						</div>
						<div class="col-lg-4 col-xs-6">
							<div class="small-box bg-aqua">
								<div class="inner">
								  <h3><?=$alfa;?></h3>

								  <p>Tanpa Keterangan</p>
								</div>
								<div class="icon">
								  <i class="fa fa-users"></i>
								</div>
							 </div>
						</div>
					</div>
				</div>
				<!-- /.box-body -->
			</div>
			<!-- /.box -->
		</div>
		<div class="col-lg-6 col-xs-12">
		  <div class="box">
			<div class="box-header with-border">
			  <h3 class="box-title">SD ISLAM AL-JANNAH</h3>
			</div>
			<div class="box-body table-responsive no-padding">
				<table class="table">
					<tr>
					  <td>NPSN</td>
					  <td>20258088</td>
					</tr>
					<tr>
					  <td>Bentuk Pendidikan</td>
					  <td>SD</td>
					</tr>
					<tr>
					  <td>Status</td>
					  <td>Swasta</td>
					</tr>
					<tr>
					  <td>Kecamatan</td>
					  <td>Kec. Gabuswetan</td>
					</tr>
					<tr>
					  <td>Kabupaten</td>
					  <td>Kab. Indramayu</td>
					</tr>
					<tr>
					  <td>Provinsi</td>
					  <td>Jawa Barat</td>
					</tr>
					<tr>
					  <td>Kepala Sekolah</td>
					  <td>Umar Ali</td>
					</tr>
					
				</table>
			</div>
			<!-- /.box-body -->
		  </div>
		  <!-- /.box -->
		</div>
	  </div>
</section>
<!-- /.content -->

<?php include "../inc/lte-script.php";?>
</body>
</html>
